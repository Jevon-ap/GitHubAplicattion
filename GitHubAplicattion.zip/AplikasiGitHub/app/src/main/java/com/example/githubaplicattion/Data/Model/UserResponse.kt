package com.example.githubaplicattion.Data.Model

import com.google.gson.annotations.SerializedName


data class UserResponse(
    @SerializedName(value="items")
    val items : ArrayList<User>
)