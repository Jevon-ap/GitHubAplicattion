package com.example.githubaplicattion

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.KeyEvent
import android.view.View
import androidx.fragment.app.FragmentManager.BackStackEntry
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubaplicattion.Data.Model.User
import com.example.githubaplicattion.UI.Detail.DetailUserActivity
import com.example.githubaplicattion.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel
    private lateinit var adapter: UserAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter= UserAdapter()
        adapter.notifyDataSetChanged()

        adapter.setOnItemClickCallback(object:UserAdapter.OnItemClickCallBack{
            override fun onItemClicked(data: User) {

                Intent(this@MainActivity,DetailUserActivity::class.java).also {
                    it.putExtra(DetailUserActivity.EXTRA_USERNAME,data.login)
                    showLoading(true)
                    startActivity(it)
                }
            }

        })
        viewModel= ViewModelProvider(this,ViewModelProvider.NewInstanceFactory()).get(MainViewModel::class.java)

        binding.apply {
            recyclerView.layoutManager = LinearLayoutManager(this@MainActivity)
            recyclerView.setHasFixedSize(true)
            recyclerView.adapter = adapter

            btnSearch.setOnClickListener{
                searchUser()
            }

            et.setOnKeyListener { view, i, keyEvent ->
                if (keyEvent.action == KeyEvent.ACTION_DOWN && i == KeyEvent.KEYCODE_ENTER){
                    return@setOnKeyListener true
                }
                return@setOnKeyListener false
            }
        }
        viewModel.getSearchUser().observe(this ,{
            if (it!=null){
                adapter.setList(it)
                showLoading(false)
            }
        })
    }
    private fun searchUser(){
        binding.apply {
            val query = et.text.toString()
            if (query.isEmpty())return
            showLoading(true)
            viewModel.setSearchUser(query)
        }
    }
    private fun showLoading(state:Boolean){
        if (state){
            binding.progress.visibility = View.VISIBLE
            binding.recyclerView.visibility=View.GONE
            Handler().postDelayed({
                binding.progress.visibility = View.GONE
                binding.recyclerView.visibility=View.VISIBLE
            }, 3000)

        }else{
            binding.progress.visibility = View.GONE
        }
    }
}