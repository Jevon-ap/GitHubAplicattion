package com.example.githubaplicattion.Data.Model

data class DetailUserResponse(
    val avatar_url:String,
    val login:String,
    val name:String,
    val followers:Int,
    val following:Int,
)
