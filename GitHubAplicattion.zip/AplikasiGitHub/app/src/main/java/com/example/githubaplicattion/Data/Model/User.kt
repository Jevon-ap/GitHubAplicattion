package com.example.githubaplicattion.Data.Model

data class User(
    val login:String,
    val id:Int,
    val avatar_url:String
)
